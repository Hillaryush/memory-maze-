import { MemoryMaze } from '@/components/MemoryMaze';

const Index = () => {
  return <MemoryMaze />;
};

export default Index;
