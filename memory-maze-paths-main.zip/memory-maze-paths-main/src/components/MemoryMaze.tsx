import React, { useState, useEffect, useCallback, useRef } from 'react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Snowflake, Map, RotateCcw, Play, Pause } from 'lucide-react';
import { toast } from 'sonner';

// Game configuration
const MAZE_SIZE = 8;
const INITIAL_SHIFT_INTERVAL = 8000; // 8 seconds
const MIN_SHIFT_INTERVAL = 2000; // 2 seconds minimum
const DIFFICULTY_INCREASE_RATE = 0.85; // Each level, multiply interval by this

// Cell types
enum CellType {
  WALL = 0,
  PATH = 1,
  PLAYER = 2,
  GOAL = 3,
  POWERUP_FREEZE = 4,
  POWERUP_MAP = 5
}

// Direction enum for movement
enum Direction {
  UP = 'UP',
  DOWN = 'DOWN',
  LEFT = 'LEFT',
  RIGHT = 'RIGHT'
}

interface Position {
  x: number;
  y: number;
}

interface PowerUp {
  type: 'freeze' | 'map';
  duration: number;
  active: boolean;
}

export const MemoryMaze: React.FC = () => {
  // Game state
  const [maze, setMaze] = useState<CellType[][]>([]);
  const [playerPos, setPlayerPos] = useState<Position>({ x: 0, y: 0 });
  const [goalPos, setGoalPos] = useState<Position>({ x: MAZE_SIZE - 1, y: MAZE_SIZE - 1 });
  const [level, setLevel] = useState(1);
  const [score, setScore] = useState(0);
  const [gameRunning, setGameRunning] = useState(false);
  const [shiftTimer, setShiftTimer] = useState(INITIAL_SHIFT_INTERVAL);
  const [currentInterval, setCurrentInterval] = useState(INITIAL_SHIFT_INTERVAL);
  
  // Power-ups
  const [powerUps, setPowerUps] = useState<{ freeze: PowerUp; map: PowerUp }>({
    freeze: { type: 'freeze', duration: 0, active: false },
    map: { type: 'map', duration: 0, active: false }
  });
  
  // Touch/swipe handling
  const touchStartRef = useRef<{ x: number; y: number } | null>(null);
  const gameContainerRef = useRef<HTMLDivElement>(null);

  // Generate a random maze with guaranteed path to goal
  const generateMaze = useCallback((): CellType[][] => {
    const newMaze: CellType[][] = Array(MAZE_SIZE).fill(null).map(() => 
      Array(MAZE_SIZE).fill(CellType.WALL)
    );
    
    // Create paths using simple maze generation
    const createPath = (x: number, y: number) => {
      if (x < 0 || x >= MAZE_SIZE || y < 0 || y >= MAZE_SIZE || newMaze[y][x] === CellType.PATH) {
        return;
      }
      
      newMaze[y][x] = CellType.PATH;
      
      // Randomly order directions for more natural paths
      const directions = [
        [0, -1], [0, 1], [-1, 0], [1, 0]
      ].sort(() => Math.random() - 0.5);
      
      directions.forEach(([dx, dy]) => {
        if (Math.random() > 0.6) { // 40% chance to continue in each direction
          createPath(x + dx, y + dy);
        }
      });
    };
    
    // Ensure start and goal are paths
    newMaze[0][0] = CellType.PATH;
    newMaze[MAZE_SIZE - 1][MAZE_SIZE - 1] = CellType.PATH;
    
    // Create initial paths
    createPath(0, 0);
    createPath(MAZE_SIZE - 1, MAZE_SIZE - 1);
    
    // Add some random paths for complexity
    for (let i = 0; i < MAZE_SIZE * 2; i++) {
      const x = Math.floor(Math.random() * MAZE_SIZE);
      const y = Math.floor(Math.random() * MAZE_SIZE);
      if (Math.random() > 0.7) {
        createPath(x, y);
      }
    }
    
    // Add power-ups occasionally
    const pathCells: Position[] = [];
    for (let y = 0; y < MAZE_SIZE; y++) {
      for (let x = 0; x < MAZE_SIZE; x++) {
        if (newMaze[y][x] === CellType.PATH && !(x === 0 && y === 0) && !(x === MAZE_SIZE - 1 && y === MAZE_SIZE - 1)) {
          pathCells.push({ x, y });
        }
      }
    }
    
    // Add 1-2 power-ups per maze
    const numPowerUps = Math.min(2, Math.floor(pathCells.length / 8));
    for (let i = 0; i < numPowerUps; i++) {
      if (pathCells.length > 0) {
        const randomIndex = Math.floor(Math.random() * pathCells.length);
        const pos = pathCells.splice(randomIndex, 1)[0];
        newMaze[pos.y][pos.x] = Math.random() > 0.5 ? CellType.POWERUP_FREEZE : CellType.POWERUP_MAP;
      }
    }
    
    return newMaze;
  }, []);

  // Initialize game
  const initializeGame = useCallback(() => {
    const newMaze = generateMaze();
    setMaze(newMaze);
    setPlayerPos({ x: 0, y: 0 });
    setGoalPos({ x: MAZE_SIZE - 1, y: MAZE_SIZE - 1 });
    setShiftTimer(currentInterval);
    toast.success(`Level ${level} - Navigate to the goal before walls shift!`);
  }, [generateMaze, currentInterval, level]);

  // Handle wall shifting
  const shiftWalls = useCallback(() => {
    if (powerUps.freeze.active) {
      toast.info("Walls frozen! 🧊");
      return;
    }
    
    setMaze(generateMaze());
    setShiftTimer(currentInterval);
    toast.warning("Walls shifted! Find the new path!");
  }, [generateMaze, currentInterval, powerUps.freeze.active]);

  // Move player
  const movePlayer = useCallback((direction: Direction) => {
    if (!gameRunning) return;
    
    setPlayerPos(prevPos => {
      let newX = prevPos.x;
      let newY = prevPos.y;
      
      switch (direction) {
        case Direction.UP:
          newY = Math.max(0, prevPos.y - 1);
          break;
        case Direction.DOWN:
          newY = Math.min(MAZE_SIZE - 1, prevPos.y + 1);
          break;
        case Direction.LEFT:
          newX = Math.max(0, prevPos.x - 1);
          break;
        case Direction.RIGHT:
          newX = Math.min(MAZE_SIZE - 1, prevPos.x + 1);
          break;
      }
      
      // Check if move is valid (not into a wall)
      if (maze[newY] && maze[newY][newX] !== CellType.WALL) {
        // Check for power-up collection
        const cellType = maze[newY][newX];
        if (cellType === CellType.POWERUP_FREEZE) {
          setPowerUps(prev => ({
            ...prev,
            freeze: { ...prev.freeze, duration: 8000, active: true }
          }));
          toast.success("Freeze power-up collected! ❄️");
          
          // Remove power-up from maze
          setMaze(prevMaze => {
            const newMaze = [...prevMaze];
            newMaze[newY] = [...newMaze[newY]];
            newMaze[newY][newX] = CellType.PATH;
            return newMaze;
          });
        } else if (cellType === CellType.POWERUP_MAP) {
          setPowerUps(prev => ({
            ...prev,
            map: { ...prev.map, duration: 3000, active: true }
          }));
          toast.success("Map revealed! 🗺️");
          
          // Remove power-up from maze
          setMaze(prevMaze => {
            const newMaze = [...prevMaze];
            newMaze[newY] = [...newMaze[newY]];
            newMaze[newY][newX] = CellType.PATH;
            return newMaze;
          });
        }
        
        return { x: newX, y: newY };
      }
      
      return prevPos;
    });
  }, [gameRunning, maze]);

  // Handle touch gestures
  const handleTouchStart = (e: React.TouchEvent) => {
    e.preventDefault();
    const touch = e.touches[0];
    touchStartRef.current = { x: touch.clientX, y: touch.clientY };
  };

  const handleTouchEnd = (e: React.TouchEvent) => {
    e.preventDefault();
    if (!touchStartRef.current) return;
    
    const touch = e.changedTouches[0];
    const deltaX = touch.clientX - touchStartRef.current.x;
    const deltaY = touch.clientY - touchStartRef.current.y;
    const threshold = 30;
    
    if (Math.abs(deltaX) > Math.abs(deltaY)) {
      if (Math.abs(deltaX) > threshold) {
        movePlayer(deltaX > 0 ? Direction.RIGHT : Direction.LEFT);
      }
    } else {
      if (Math.abs(deltaY) > threshold) {
        movePlayer(deltaY > 0 ? Direction.DOWN : Direction.UP);
      }
    }
    
    touchStartRef.current = null;
  };

  // Keyboard controls
  useEffect(() => {
    const handleKeyPress = (e: KeyboardEvent) => {
      switch (e.key) {
        case 'ArrowUp':
        case 'w':
          e.preventDefault();
          movePlayer(Direction.UP);
          break;
        case 'ArrowDown':
        case 's':
          e.preventDefault();
          movePlayer(Direction.DOWN);
          break;
        case 'ArrowLeft':
        case 'a':
          e.preventDefault();
          movePlayer(Direction.LEFT);
          break;
        case 'ArrowRight':
        case 'd':
          e.preventDefault();
          movePlayer(Direction.RIGHT);
          break;
      }
    };

    if (gameRunning) {
      window.addEventListener('keydown', handleKeyPress);
      return () => window.removeEventListener('keydown', handleKeyPress);
    }
  }, [gameRunning, movePlayer]);

  // Game timers
  useEffect(() => {
    if (!gameRunning) return;
    
    const timer = setInterval(() => {
      setShiftTimer(prev => {
        if (prev <= 100) {
          shiftWalls();
          return currentInterval;
        }
        return prev - 100;
      });
    }, 100);
    
    return () => clearInterval(timer);
  }, [gameRunning, shiftWalls, currentInterval]);

  // Power-up timers
  useEffect(() => {
    Object.entries(powerUps).forEach(([key, powerUp]) => {
      if (powerUp.active && powerUp.duration > 0) {
        const timer = setTimeout(() => {
          setPowerUps(prev => ({
            ...prev,
            [key]: { ...prev[key as keyof typeof prev], duration: 0, active: false }
          }));
        }, powerUp.duration);
        
        return () => clearTimeout(timer);
      }
    });
  }, [powerUps]);

  // Check for goal reached
  useEffect(() => {
    if (playerPos.x === goalPos.x && playerPos.y === goalPos.y && gameRunning) {
      const levelScore = Math.max(100, Math.floor(shiftTimer / 10));
      setScore(prev => prev + levelScore);
      setLevel(prev => prev + 1);
      setCurrentInterval(prev => Math.max(MIN_SHIFT_INTERVAL, prev * DIFFICULTY_INCREASE_RATE));
      toast.success(`Level completed! +${levelScore} points! 🎉`);
      
      setTimeout(() => {
        initializeGame();
      }, 1000);
    }
  }, [playerPos, goalPos, gameRunning, shiftTimer, initializeGame]);

  // Start/stop game
  const toggleGame = () => {
    if (!gameRunning) {
      setGameRunning(true);
      initializeGame();
    } else {
      setGameRunning(false);
    }
  };

  const resetGame = () => {
    setGameRunning(false);
    setLevel(1);
    setScore(0);
    setCurrentInterval(INITIAL_SHIFT_INTERVAL);
    setPowerUps({
      freeze: { type: 'freeze', duration: 0, active: false },
      map: { type: 'map', duration: 0, active: false }
    });
  };

  // Initialize on mount
  useEffect(() => {
    initializeGame();
  }, []);

  const renderCell = (cell: CellType, x: number, y: number) => {
    const isPlayer = x === playerPos.x && y === playerPos.y;
    const isGoal = x === goalPos.x && y === goalPos.y;
    const showMapReveal = powerUps.map.active;
    
    let cellClass = "maze-cell w-full h-full flex items-center justify-center text-xs font-medium ";
    
    if (cell === CellType.WALL) {
      cellClass += "maze-wall ";
      if (showMapReveal) cellClass += "opacity-50 ";
    } else {
      cellClass += "maze-path ";
    }
    
    if (isGoal) {
      cellClass += "bg-gradient-to-br from-success to-green-400 animate-pulse ";
    }
    
    return (
      <div key={`${x}-${y}`} className={cellClass}>
        {isPlayer && (
          <div className="player-character w-3/4 h-3/4 flex items-center justify-center text-white font-bold">
            😊
          </div>
        )}
        {isGoal && !isPlayer && (
          <div className="text-white text-lg">🎯</div>
        )}
        {cell === CellType.POWERUP_FREEZE && (
          <div className="powerup-item w-3/4 h-3/4 bg-powerup-freeze flex items-center justify-center">
            <Snowflake className="w-3 h-3 text-white" />
          </div>
        )}
        {cell === CellType.POWERUP_MAP && (
          <div className="powerup-item w-3/4 h-3/4 bg-powerup-map flex items-center justify-center">
            <Map className="w-3 h-3 text-white" />
          </div>
        )}
      </div>
    );
  };

  const getTimerColor = () => {
    const percentage = (shiftTimer / currentInterval) * 100;
    if (percentage < 20) return "text-timer-critical";
    if (percentage < 50) return "text-timer-warning";
    return "text-primary";
  };

  return (
    <div 
      ref={gameContainerRef}
      className="min-h-screen bg-gradient-to-br from-background to-background-secondary p-4 flex flex-col items-center justify-center font-game"
      onTouchStart={handleTouchStart}
      onTouchEnd={handleTouchEnd}
    >
      {/* Header */}
      <div className="w-full max-w-md mb-4">
        <Card className="game-ui p-4">
          <div className="text-center mb-2">
            <h1 className="text-2xl font-bold text-primary mb-1">Memory Maze</h1>
            <p className="text-sm text-muted-foreground">Shifting Paths</p>
          </div>
          
          <div className="flex justify-between items-center text-sm">
            <div>Level: <span className="font-bold text-primary">{level}</span></div>
            <div>Score: <span className="font-bold text-accent">{score}</span></div>
          </div>
          
          {gameRunning && (
            <div className="mt-3 text-center">
              <div className={`text-lg font-bold ${getTimerColor()}`}>
                {Math.ceil(shiftTimer / 1000)}s
              </div>
              <div className="text-xs text-muted-foreground">until walls shift</div>
              
              {/* Power-up indicators */}
              <div className="flex justify-center gap-2 mt-2">
                {powerUps.freeze.active && (
                  <div className="flex items-center gap-1 text-xs bg-powerup-freeze text-white px-2 py-1 rounded-full">
                    <Snowflake className="w-3 h-3" />
                    {Math.ceil(powerUps.freeze.duration / 1000)}s
                  </div>
                )}
                {powerUps.map.active && (
                  <div className="flex items-center gap-1 text-xs bg-powerup-map text-white px-2 py-1 rounded-full">
                    <Map className="w-3 h-3" />
                    {Math.ceil(powerUps.map.duration / 1000)}s
                  </div>
                )}
              </div>
            </div>
          )}
        </Card>
      </div>

      {/* Game Board */}
      <div className="w-full max-w-md mb-4">
        <Card className="game-ui p-2 animate-maze-pulse">
          <div 
            className="grid grid-cols-8 gap-0.5 aspect-square bg-maze-bg rounded-lg p-2"
            style={{ gridTemplateRows: `repeat(${MAZE_SIZE}, 1fr)` }}
          >
            {maze.map((row, y) => 
              row.map((cell, x) => renderCell(cell, x, y))
            )}
          </div>
        </Card>
      </div>

      {/* Controls */}
      <div className="w-full max-w-md">
        <Card className="game-ui p-4">
          <div className="flex gap-2 justify-center">
            <Button 
              onClick={toggleGame}
              variant={gameRunning ? "secondary" : "default"}
              className="flex items-center gap-2"
            >
              {gameRunning ? (
                <>
                  <Pause className="w-4 h-4" />
                  Pause
                </>
              ) : (
                <>
                  <Play className="w-4 h-4" />
                  {level === 1 && score === 0 ? 'Start' : 'Resume'}
                </>
              )}
            </Button>
            
            <Button 
              onClick={resetGame}
              variant="outline"
              className="flex items-center gap-2"
            >
              <RotateCcw className="w-4 h-4" />
              Reset
            </Button>
          </div>
          
          <div className="text-center mt-4 text-xs text-muted-foreground">
            Swipe or use arrow keys to move
          </div>
        </Card>
      </div>
    </div>
  );
};